let img;
let vid;
let moonImg;
let layers = [];
let staticLayer;
let centralLayer;
let lastMouseX, lastMouseY;
let moveLayers = false;
let videoOpacity = 255;
let moonOpacity = 0;
let moonScale = 0.05; // גודל התחלתי קטן יותר של הירח
let textOpacity = 0; // אופסיטי התחלתי של הטקסט
let zoomLevel = 1;
let scrollSpeed = 0.02;
let moonScaleSpeed = 0.02; // מהירות גידול הירח

function preload() {
  img = loadImage("backround.png");
  vid = createVideo("Spacesuithead.mp4");
  moonImg = loadImage("moon3.png"); // טעינת תמונת הירח
  vid.hide(); // הסתרת הוידאו כדי שנוכל לצייר אותו על הקנווס

  // טעינת פונט
  textFont(loadFont('NarkisBlock.otf'));
}

function setup() {
  createCanvas(1920, 1080);

  // הגדרת פרטי הוידאו
  vid.size(1920, 1080);
  vid.volume(1);
  vid.loop();

  // יצירת שכבת כדורים מרכזית דמויית גלקסיה
  centralLayer = new CentralLayer(3000); // שינוי לכמות גדולה יותר של כדורים

  // יצירת השכבה הסטטית
  staticLayer = new StaticLayer(500);

  // יצירת 4 שכבות נעות
  for (let i = 0; i < 4; i++) {
    layers.push(new Layer(200, 1 + i * 0.5, 0.005 - i * 0.001)); // מהירות קווית ומהירות סיבוב
  }

  // מאזין לאירועי גלילה
  window.addEventListener('wheel', handleScroll);
}

function draw() {
  // ציור תמונת הרקע עם זום
  background(50);
  imageMode(CENTER);
  push();
  translate(width / 2, height / 2);
  scale(zoomLevel);
  image(img, 0, 0, 1920, 1080);
  pop();

  // ציור השכבה המרכזית
  centralLayer.display();

  // ציור השכבה הסטטית
  staticLayer.display();

  // עדכון וציור השכבות הנעות
  for (let layer of layers) {
    if (moveLayers) {
      layer.updatePositionWithMouse(mouseX - lastMouseX, mouseY - lastMouseY);
    }
    layer.update();
    layer.display();
  }

  // חישוב מיקום הוידאו בהתאם לתנועת העכבר עם טווח גדול יותר
  let offsetX = map(mouseX, 0, width, 30, -30);
  let offsetY = map(mouseY, 0, height, 30, -30);

  // ציור הוידאו כשכבה עליונה עם הסרת הרקע השחור ותנודה וזום
  let videoFrame = vid.get();
  imageMode(CENTER);
  tint(255, videoOpacity); // שקיפות בהתאם לאופסיטי
  blendMode(SCREEN); // מצב בלנד להסרת שחור
  push();
  translate(width / 2 + offsetX, height / 2 + offsetY);
  scale(zoomLevel);
  image(videoFrame, 0, 0, 1920, 1080); // הקטנה של הוידאו במעט ותנודה
  pop();
  blendMode(BLEND); // חזרה למצב בלנד רגיל
  noTint(); // הסרת שקיפות

  // עדכון אופסיטי וגודל הירח
  if (moonOpacity >= 90) {
    textOpacity = map(moonOpacity, 90, 255, 0, 255);
  } else {
    textOpacity = 0;
  }

  // ציור תמונת הירח מעל כל השכבות עם אופסיטי וזום
  imageMode(CENTER);
  tint(255, moonOpacity);
  push();
  translate(width / 2, height / 2);
  scale(moonScale);
  image(moonImg, 0, 0);
  pop();
  noTint(); // הסרת שקיפות

  // ציור כותרת וטקסט סטטי בצד שמאל של הקנבס
  fill(255, textOpacity);
  textSize(48); // גודל כותרת מוקטן
  textAlign(LEFT);
  text("Moon", 50, height / 2 - 100); // הרמת הכותרת קצת יותר למעלה

  textSize(28); // גודל טקסט מוקטן
  text("The moon is the only natural satellite of the Earth. It is also called Lebna or Crescent in Hebrew, and Luna in the scientific nomenclature in Latin, and this is to distinguish it from the moons of other heavenly bodies. Its diameter is 3,474 kilometers, slightly more than a quarter of the diameter of the Earth. The relative closeness in size between the Earth and its Moon is rare.", 50, height / 2 - 50, width / 3);

  // עדכון מיקום העכבר האחרון
  lastMouseX = mouseX;
  lastMouseY = mouseY;
}

function handleScroll(event) {
  if (event.deltaY < 0) { // גלילה למעלה
    videoOpacity -= 30; // שינוי מהיר יותר של האופסיטי
    zoomLevel += scrollSpeed;
    moonOpacity += 15; // שינוי מהיר יותר של אופסיטי הירח
    moonScale += moonScaleSpeed; // שינוי מהיר יותר של גודל הירח
    for (let layer of layers) {
      layer.moveBallsFromCenter(-scrollSpeed * 100);
    }
  } else if (event.deltaY > 0) { // גלילה למטה
    videoOpacity += 30; // שינוי מהיר יותר של האופסיטי
    zoomLevel -= scrollSpeed;
    moonOpacity -= 15; // שינוי מהיר יותר של אופסיטי הירח
    moonScale -= moonScaleSpeed; // שינוי מהיר יותר של גודל הירח
    for (let layer of layers) {
      layer.moveBallsFromCenter(scrollSpeed * 100);
    }
  }

  videoOpacity = constrain(videoOpacity, 0, 255);
  zoomLevel = constrain(zoomLevel, 1, 2); // הגבלת רמת הזום
  moonOpacity = constrain(moonOpacity, 0, 255); // הגבלת אופסיטי הירח
  moonScale = constrain(moonScale, 0.01, 0.8); // הגבלת גודל הירח
}

function mousePressed() {
  moveLayers = true; // הפעלת מצב תזוזת השכבות
  lastMouseX = mouseX;
  lastMouseY = mouseY;
}

function mouseReleased() {
  moveLayers = false; // ביטול מצב תזוזת השכבות
}

class CentralLayer {
  constructor(ballCount) {
    this.balls = [];
    let centerX = width / 2;
    let centerY = height / 2;

    for (let i = 0; i < ballCount; i++) {
      let angle = random(TWO_PI);
      let radius = randomGaussian() * width / 4;
      let density = map(abs(radius), 0, width / 2, 0.5, 3);
      let x = centerX + cos(angle) * radius;
      let y = centerY + sin(angle) * radius;
      this.balls.push(new Ball(x, y, random(0.5, 1.5), angle, 'white'));
    }
  }

  display() {
    for (let ball of this.balls) {
      ball.display();
    }
  }
}

class StaticLayer {
  constructor(ballCount) {
    this.balls = [];

    for (let i = 0; i < ballCount; i++) {
      let x, y;
      if (random() < 0.7) {
        x = random(width * 0.25, width * 0.75);
        y = random(height * 0.25, height * 0.75);
      } else {
        x = random(width);
        y = random(height);
      }
      this.balls.push(new Ball(x, y, random(0.25, 1.5)));
    }
  }

  display() {
    for (let ball of this.balls) {
      ball.display();
    }
  }
}

class Layer {
  constructor(ballCount, speed, rotationSpeed) {
    this.balls = [];
    this.speed = speed;
    this.rotationSpeed = rotationSpeed;

    for (let i = 0; i < ballCount; i++) {
      let x = random(width);
      let y = random(height);
      let angle = random(TWO_PI);
      this.balls.push(new Ball(x, y, random(0.5, 3.5), angle));
    }
  }

  update() {
    for (let ball of this.balls) {
      ball.x += this.speed;
      ball.angle += this.rotationSpeed;
      ball.updatePosition();

      if (ball.screenX > width + 10) {
        ball.x = -10;
        ball.updatePosition();
      }
    }
  }

  updatePositionWithMouse(dx, dy) {
    for (let ball of this.balls) {
      ball.x += dx * 0.5; // תזוזה עם כיוון העכבר
      ball.y += dy * 0.5; // תזוזה עם כיוון העכבר
      ball.updatePosition();
    }
  }

  moveBallsFromCenter(amount) {
    for (let ball of this.balls) {
      let angle = atan2(ball.y - height / 2, ball.x - width / 2);
      ball.x += cos(angle) * amount;
      ball.y += sin(angle) * amount;
      ball.updatePosition();
    }
  }

  display() {
    push();
    scale(zoomLevel);
    for (let ball of this.balls) {
      ball.display();
    }
    pop();
  }
}

class Ball {
  constructor(x, y, size, angle = 0, color = null) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.angle = angle;
    this.radius = random(100, 300);
    this.color = color ? color : random(['rgb(255,228,228)', 'rgb(252,252,218)', 'white']);
    this.updatePosition();
  }

  updatePosition() {
    this.screenX = this.x + cos(this.angle) * this.radius;
    this.screenY = this.y;
    let z = sin(this.angle) * this.radius;

    // חישוב גודל העיגול בהתאם למרחק מהמצלמה
    this.scale = map(z, -this.radius, this.radius, 0.5, 1.5);
  }

  display() {
    let size = this.size * this.scale;

    noStroke();
    fill(this.color);
    circle(this.screenX, this.screenY, size);

    // הוספת זוהר
    drawingContext.shadowBlur = 3 * this.scale;
    drawingContext.shadowColor = this.color;
    circle(this.screenX, this.screenY, size);
    drawingContext.shadowBlur = 0;
  }
}